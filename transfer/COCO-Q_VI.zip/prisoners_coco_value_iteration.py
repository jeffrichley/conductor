from utils import *
import numpy as np
from numpy import unravel_index
import itertools

# This is where we will keep our COCO-Q values for learning
p1_q_values_final = np.zeros((9, 9))
p2_q_values_final = np.zeros((9, 9))

# these copies are used to figure out how much change happens each iteration so we know when to stop
last_p1_values = p1_q_values_final.copy()
last_p2_values = p2_q_values_final.copy()

# list of all states that are possible for our game
all_states = list(itertools.product([0, 1, 2, 3, 4], [4, 5, 6, 7, 8]))

max_change = 10000
min_change = 10000
count = 0

# main loop for training
# we will keep iterating until there is very little change
while max_change > 0.001:
    count += 1

    # we will update all states
    for state in all_states:

        # 1. build up the payoff matrix of this state
        p1_payoff, p2_payoff = get_payoff_matrices_for_state(state, p1_q_values_final, p2_q_values_final)

        # 2. calculate the maxmax value of the two payoff matrices
        maxmax_value = ((p1_payoff + p2_payoff) / 2).max()

        # 3. calculate the minimax value for each player
        p1_minimax_value = minimax_value((p1_payoff - p2_payoff) / 2)
        # TODO: do we actually need to calculate this?  it may always be the negative of
        #       each other because it is a zero sum game?
        p2_minimax_value = minimax_value((p2_payoff.transpose() - p1_payoff.transpose()) / 2)

        # 4. calculate the coco value for each player
        p1_coco_value = maxmax_value + p1_minimax_value
        p2_coco_value = maxmax_value + p2_minimax_value

        # 5. update the q values for the current state
        discount = 0.99
        p1_q_values_final[state] = p1_coco_value * discount
        p2_q_values_final[state] = p2_coco_value * discount

    # let's see what the largest change was for this past iteration, if it is less than a certain amount
    # we can stop updating our values for each state
    max_change = max((p1_q_values_final - last_p1_values).max(), (p2_q_values_final - last_p2_values).max())
    min_change = min(min_change, max_change)

    last_p1_values = p1_q_values_final.copy()
    last_p2_values = p2_q_values_final.copy()

print(f'Performed {count} value iterations')

# 6. move to a new states
# figure out what each player will do and simulate it
current_state = (3, 5)
print('state     actions       resulting state\t\tvisual state')
game_state = ['G', '_', '_', '_', 'G', '_', '_', '_', 'G']
game_state[current_state[0]] = '1'
game_state[current_state[1]] = '2'
print(f'start\t\t\t\t\t\t\t\t\t\t{"".join(game_state)}')
while not is_terminal_state(current_state):

    # this will allow us to take a greedy action that has been previously learned
    p1_expectations = np.zeros((3, 3))
    p2_expectations = np.zeros((3, 3))

    # p1_rewards = np.zeros((3,3))
    # p2_rewards = np.zeros((3, 3))

    all_joint_action_pairs = list(itertools.product([0, 1, 2], [0, 1, 2]))

    p1_best_reward = -999999
    p2_best_reward = -999999

    # gather all outcomes to the join actions that can be played
    for p1_joint_action, p2_joint_action in all_joint_action_pairs:
        p1_reward, p2_reward = get_rewards_for_state_joint_action(current_state, p1_joint_action, p2_joint_action)

        # p1_rewards[p1_joint_action][p2_joint_action] = p1_reward
        # p2_rewards[p1_joint_action][p2_joint_action] = p2_reward

        p1_best_reward = max(p1_reward, p1_best_reward)
        p2_best_reward = max(p2_reward, p2_best_reward)

        state_prime = game_step(current_state, p1_joint_action, p2_joint_action)

        p1_value = p1_reward + p1_q_values_final[state_prime]
        p2_value = p2_reward + p2_q_values_final[state_prime]

        p1_expectations[p1_joint_action][p2_joint_action] = p1_value
        p2_expectations[p1_joint_action][p2_joint_action] = p2_value

    # calculate the combined expectations
    combined_expectations = p1_expectations + p2_expectations

    # p1_minimax = int(minimax_value(p1_rewards))
    # p2_minimax = int(minimax_value(p2_rewards.transpose()))
    # p1_coco = get_coco_values(p1_rewards, p2_rewards)

    # take the highest scoring joint action
    p1_action, p2_action = unravel_index(combined_expectations.argmax(), combined_expectations.shape)
    prev_state = current_state
    current_state = game_step(current_state, p1_action, p2_action)

    game_state = ['G', '_', '_', '_', 'G', '_', '_', '_', 'G']
    game_state[current_state[0]] = '1'
    game_state[current_state[1]] = '2'

    print(f'{prev_state} -> {action_space[p1_action]} {action_space[p2_action]:5} -> {current_state}\t\t\t\t{"".join(game_state)}')
    # print(f'\tBest individual payouts would be: p1 {p1_best_reward} p2 {p2_best_reward}')
    # print(f'\tMinimax: p1 {p1_minimax} p2 {p2_minimax}')
    # print(p1_coco)


