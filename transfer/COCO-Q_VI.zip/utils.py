import itertools
from prisoner_game import *
from cvxopt import matrix, solvers
from cvxopt.solvers import options
options['show_progress'] = False
solvers.options['show_progress'] = False # disable solver output
solvers.options['glpk'] = {'msg_lev': 'GLP_MSG_OFF'}  # cvxopt 1.1.8
solvers.options['LPX_K_MSGLEV'] = 0  # previous versions


def maxmin(A, solver="glpk"):

    original_A = A.copy()

    # https://adamnovotnycom.medium.com/linear-programming-in-python-cvxopt-and-game-theory-8626a143d428

    num_vars = len(A)
    # minimize matrix c
    c = [-1] + [0 for i in range(num_vars)]
    c = np.array(c, dtype="float")
    c = matrix(c)

    # constraints G*x <= h
    G = np.matrix(A, dtype="float").T  # reformat each variable is in a row
    G *= -1  # minimization constraint
    G = np.vstack([G, np.eye(num_vars) * -1])  # > 0 constraint for all vars
    new_col = [1 for i in range(num_vars)] + [0 for i in range(num_vars)]
    G = np.insert(G, 0, new_col, axis=1)  # insert utility column
    G = matrix(G)
    h = ([0 for i in range(num_vars)] +
         [0 for i in range(num_vars)])
    h = np.array(h, dtype="float")
    h = matrix(h)

    # contraints Ax = b
    A = [0] + [1 for i in range(num_vars)]
    A = np.matrix(A, dtype="float")
    A = matrix(A)
    b = np.matrix(1, dtype="float")
    b = matrix(b)
    sol = solvers.lp(c=c, G=G, h=h, A=A, b=b, solver=solver)

    probs = sol['x'][1:]

    return probs


def get_coco_values(player1_vals, player2_vals):

    plus = player1_vals + player2_vals
    max_value = (plus / 2).max()

    # TODO: this is using maximin? Need to verify which version this is computing
    # minimax_probability_value = maxmin_value(player1_vals, player2_vals)
    minus = player1_vals - player2_vals
    minimax_probability_value = minimax_value(minus/2)

    p1_coco_value = max_value + minimax_probability_value
    p2_coco_value = max_value - minimax_probability_value

    return p1_coco_value, p2_coco_value


def minimax_value(vals):
    mm1 = maxmin(vals)
    mm2 = maxmin(-vals.transpose())
    probs = np.outer(mm1, mm2)
    tots = vals * probs
    answer = tots.sum()

    return answer


def get_rewards_for_state_joint_action(current_state, p1_action, p2_action):
    state_prime = game_step(current_state, p1_action, p2_action)
    p1_reward, p2_reward = get_rewards(state_prime)

    # if it is a non-terminal state and they didn't stand still, we deduct a point
    if p1_reward == 0 and p1_action != 2:
        p1_reward = -1

    if p2_reward == 0 and p2_action != 2:
        p2_reward = -1

    return p1_reward, p2_reward


def get_payoff_matrices_for_state(current_state, p1_q_values, p2_q_values):

    # initialize the matrices
    p1_payoff = np.zeros((3, 3))
    p2_payoff = np.zeros((3, 3))

    # get all joint action pairs
    all_joint_action_pairs = list(itertools.product([0, 1, 2], [0, 1, 2]))

    for p1_action, p2_action in all_joint_action_pairs:

        # get the reward we would have received had we taken this action
        if is_terminal_state(current_state):
            q_p1 = 0
            q_p2 = 0
        else:
            p1_reward, p2_reward = get_rewards_for_state_joint_action(current_state, p1_action, p2_action)
            state_prime = game_step(current_state, p1_action, p2_action)

            # get the next state's value
            p1_state_prime_q_value = p1_q_values[state_prime]
            p2_state_prime_q_value = p2_q_values[state_prime]

            # calculate this cells value
            discount = 1.0
            q_p1 = p1_reward + (p1_state_prime_q_value * discount)
            q_p2 = p2_reward + (p2_state_prime_q_value * discount)

        # set the payoff matrices' cell values
        p1_payoff[p1_action][p2_action] = q_p1
        p2_payoff[p1_action][p2_action] = q_p2

    return p1_payoff, p2_payoff
